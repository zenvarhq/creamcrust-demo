/* Public observations, not owner-approved business information. */
window.CREAMCRUST_BUSINESS = {
  "name": "CreamCrust Café",
  "locality": "Hosur",
  "street": "Bagalur Road",
  "addressLines": [
    "39/1/1, TNHB Colony",
    "Bagalur Road, Hosur",
    "Tamil Nadu 635109"
  ],
  "phone": "+91 82203 62090",
  "phoneHref": "tel:+918220362090",
  "hours": "Hours unconfirmed. Public listings differ.",
  "lastChecked": "2026-10-25",
  "approvedByOwner": false,
  "verificationMethod": "Supplied 25 October public-evidence register; no direct business confirmation",
  "sourceUrl": "https://www.zomato.com/hosur/cream-crust-cafe-hosur-locality",
  "links": {
    "maps": "https://www.google.com/maps/search/?api=1&query=CreamCrust+Cafe+Bagalur+Road+Hosur",
    "swiggy": "https://www.swiggy.com/city/hosur/creamcrust-cafe-hosur-city-rest1196332",
    "zomato": "https://www.zomato.com/hosur/cream-crust-cafe-hosur-locality",
    "instagram": "https://www.instagram.com/creamcrust.cafe/"
  },
  "linkApproval": "Public reference destinations; owner approval and exact Maps pin pending",
  "instagramStatus": "Unverified public profile lead",
  "disclaimers": {
    "preview": "Unofficial ZENVAR design demonstration",
    "photography": "Concept preview · illustrative photography",
    "business": "Publicly listed details · pending confirmation",
    "wordmark": "Proposed wordmark by ZENVAR"
  },
  "menu": {
    "sourceDate": "2026-10-24",
    "sourceUrl": "https://www.swiggy.com/city/hosur/creamcrust-cafe-hosur-city-rest1196332",
    "priceContext": "Public delivery listing · check before ordering",
    "notice": "40 public-listing observations from 24 October 2026. Dine-in prices, ingredients and availability remain unverified.",
    "approvedForLiveUse": false
  },
  "noContact": {
    "from": "2026-10-25",
    "through": "2026-11-23",
    "contactActionsEnabled": false
  },
  "deployment": {
    "publiclyDeployed": true,
    "publicUrl": "https://zenvarhq.github.io/creamcrust-demo/",
    "repositoryUrl": "https://github.com/zenvarhq/creamcrust-demo",
    "hosting": "GitHub Pages",
    "status": "Public unofficial demonstration; business approval pending",
    "noindex": true
  }
};
